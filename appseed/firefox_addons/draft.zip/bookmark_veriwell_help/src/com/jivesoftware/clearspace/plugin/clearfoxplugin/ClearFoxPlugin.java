/**
 * $Revision$
 * $Date$
 *
 * Copyright (C) 1999-2005 Jive Software. All rights reserved.
 * This software is the proprietary information of Jive Software. Use is subject to license terms.
 */
package com.jivesoftware.clearspace.plugin.clearfoxplugin;

import com.jivesoftware.base.plugin.Plugin;
import com.jivesoftware.base.plugin.PluginMetaData;
import com.jivesoftware.base.plugin.PluginManager;
import com.jivesoftware.base.Log;
import com.jivesoftware.community.JiveGlobals;

import java.io.*;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipEntry;

import org.apache.commons.io.FileUtils;

/**
 * Constants related to the Clearfox plugin.
 */
public class ClearFoxPlugin implements Plugin {

    public static final String VERSION = "1.2";
    public static final String REFRESH_RATE = "clearfox.refreshrate";
    public static final int REFRESH_DEFAULT = 300;

    public void initializePlugin(PluginManager manager, PluginMetaData metaData) {

        File pluginDir = metaData.getPluginDirectory();
        String jarPath = pluginDir.getPath() + File.separator + "xpi" + File.separator + "chrome";
        File chromeContentPath = new File(jarPath + File.separator + "content");
        File chromeLocalePath = new File(jarPath + File.separator + "locale");
        File chromeSkinPath = new File(jarPath + File.separator + "skin");
        // content, locale, skin directories
        File[] jarPaths = {chromeContentPath, chromeSkinPath, chromeLocalePath};
        String jarFile = jarPath + File.separator + "clearfox.jar";

        String xpiPath = pluginDir.getPath() + File.separator + "xpi";
        // chrome directory and chrome.manifest, install.rdf files
        File xpiChromePath = new File(xpiPath + File.separator + "chrome");
        File xpiChromeManifestPath = new File(xpiPath + File.separator + "chrome.manifest");
        File xpiInstallRDF = new File(xpiPath + File.separator + "install.rdf");
        File[] xpiPaths = {xpiChromePath, xpiChromeManifestPath, xpiInstallRDF};

        String xpiFile = pluginDir.getPath() + File.separator + "clearfox.xpi";

        updateXPIURLS(pluginDir);

        File pluginJARFile = new File(jarFile);
        createZIP(jarPath, pluginJARFile, jarPaths);
        
        File pluginXPIFile = new File(xpiFile);
        createZIP(xpiPath, pluginXPIFile, xpiPaths);
    }

    public void destroyPlugin() {

    }

    /**
     * Updates the URL stored in /xpi/chrome/content/overlay.js and the URLs in
     * /xpi/install.rdf
     * @param pluginDir the directory where the plugin
     */
    private void updateXPIURLS(File pluginDir) {

        String ju = JiveGlobals.getDefaultBaseURL();

        try {
            File installRDFFile = new File(pluginDir.getPath() + File.separator +
                "xpi" + File.separator + "install.rdf");
            String installRDF = FileUtils.readFileToString(installRDFFile, JiveGlobals.getCharacterEncoding());
            installRDF = installRDF.replaceAll("CLEARFOXHOMEPAGEURL", ju + "/cf-about.jspa");
            installRDF = installRDF.replaceAll("CLEARFOXUPDATEURL", ju + "/cf-updater.jspa");
            installRDF = installRDF.replaceAll("CLEARFOXVERSION", ClearFoxPlugin.VERSION);
            FileUtils.writeStringToFile(installRDFFile, installRDF, JiveGlobals.getCharacterEncoding());

            File overlay = new File(pluginDir.getPath() + File.separator +
                    "xpi" + File.separator + "chrome" + File.separator +
                    "content" + File.separator + "overlay.js");
            String overlayJS = FileUtils.readFileToString(overlay, JiveGlobals.getCharacterEncoding());
            FileUtils.writeStringToFile(overlay, overlayJS.replaceAll("CLEARFOXURL", ju + "/cf-view.jspa"),
                    JiveGlobals.getCharacterEncoding());
        }
        catch (IOException e) {
            // ignore
        }
    }

    /**
     * Create a zip file given a destination and list of files to zip up.
     * @param rootPath the name of the path to replace when adding files to the zip
     * @param destination the file representing the new zip file
     * @param source a list of files to include in the zip file.
     */
    private void createZIP(String rootPath, File destination, File[] source) {
       try {
           FileOutputStream stream = new FileOutputStream(destination);
           ZipOutputStream out = new ZipOutputStream(stream);
           for (File aSource : source) {
               zipFile(rootPath, destination, aSource, out);
           }
           out.close();
           stream.close();
       }
       catch (Exception e) {
           Log.error("Error creating zip file", e);
       }
    }

    private void zipDirectory(String rootPath, File destination, File dir, ZipOutputStream out) throws Exception {
       String[] files = dir.list();
        for (String file : files) {
            File f = new File(dir, file);
            if (f.isDirectory()) {
                zipDirectory(rootPath, destination, f, out);
            } else {
                zipFile(rootPath, destination, f, out);
            }
        }
    }

    private void zipFile(String rootPath, File destination, File file, ZipOutputStream out) throws Exception {
       if (file.isDirectory()) {
           zipDirectory(rootPath, destination, file, out);
           return;
       }
       int BUFFER_SIZE = 10240000;
       byte buffer[] = new byte[BUFFER_SIZE];
       String zipFilePath = file.getPath();
       if (File.separatorChar != '/') {
           // workaround for http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4244499
           zipFilePath = zipFilePath.replace('\\', '/');
       }
       ZipEntry zipAdd = new ZipEntry(zipFilePath.substring(rootPath.length() + 1));
       out.putNextEntry(zipAdd);
       FileInputStream in = new FileInputStream(file.getAbsolutePath());
       int len;
       while ((len = in.read(buffer)) > 0) {
        out.write(buffer, 0, len);
       }
       in.close();
       out.closeEntry();
   }


}
