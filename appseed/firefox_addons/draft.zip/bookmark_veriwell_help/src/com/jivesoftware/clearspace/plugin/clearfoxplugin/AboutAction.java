/**
 * $Revision$
 * $Date$
 *
 * Copyright (C) 1999-2005 Jive Software. All rights reserved.
 * This software is the proprietary information of Jive Software. Use is subject to license terms.
 */

package com.jivesoftware.clearspace.plugin.clearfoxplugin;

import com.jivesoftware.community.action.JiveActionSupport;

/**
 * Simple action that shows an 'About This Plugin / Download' page.
 */
public class AboutAction extends JiveActionSupport {

    public String execute() {

        return SUCCESS;
    }
}
