/**
 * $Revision$
 * $Date$
 *
 * Copyright (C) 1999-2005 Jive Software. All rights reserved.
 * This software is the proprietary information of Jive Software. Use is subject to license terms.
 */
package com.jivesoftware.clearspace.plugin.clearfoxplugin;

import com.jivesoftware.community.action.MainAction;
import com.jivesoftware.community.action.util.AlwaysAllowAnonymous;
import com.jivesoftware.community.JiveContentObject;
import com.jivesoftware.base.User;

import java.util.*;

/**
 * 
 */
@AlwaysAllowAnonymous
public class ViewAction extends MainAction {

    // default poll interval = 5 minutes
    private int pollInterval = ClearFoxPlugin.REFRESH_DEFAULT;
    private long currentMarker = 0;
    private Iterable<JiveContentObject> content;
    private String view = "home";

    public int getPollInterval() {
        return pollInterval;
    }

    public void setPollInterval(int pollInterval) {
        this.pollInterval = pollInterval;
    }

    public long getCurrentMarker() {
        return currentMarker;
    }

    public void setCurrentMarker(long currentMarker) {
        this.currentMarker = currentMarker;
    }

    public Iterable<JiveContentObject> getContent() {
        return content;
    }

    public String getView() {
        return view;
    }


    /**
     * Called by AJAX to find the modification date of the first item
     * in the content list.
     * @return
     */
    public String doUpdate() {

        super.execute();
        List<JiveContentObject> clearfoxContent = new ArrayList<JiveContentObject>();
        for (JiveContentObject co : super.getContent()) {
            if (co.getModificationDate().getTime() > currentMarker) {
                clearfoxContent.add(co);
            }
        }

        if (clearfoxContent.size() > 0) {
            currentMarker = clearfoxContent.get(0).getModificationDate().getTime();
        }

        content = clearfoxContent;
        
        return "update";
    }

    


    /**
     * Default method, produces the view for the Clearfox plugin
     * @return success
     */
    public String execute() {

        if (getUser() == null) {
            view = "login";
            return SUCCESS;
        } else {
            User currentUser = getUser();
            // see if the user has set the poll interval
            if (currentUser.getProperties().get(ClearFoxPlugin.REFRESH_RATE) != null) {
                String pi = currentUser.getProperties().get(ClearFoxPlugin.REFRESH_RATE);
                try {
                    pollInterval = Integer.parseInt(pi);
                }
                catch (NumberFormatException e) {
                    // ignore
                }
            }
            super.execute();

            List<JiveContentObject> clearfoxContent = new ArrayList<JiveContentObject>();
            for (JiveContentObject co : super.getContent()) {
                clearfoxContent.add(co);
            }

            content = clearfoxContent;

            if (clearfoxContent.size() > 0) {
                currentMarker = clearfoxContent.get(0).getModificationDate().getTime();
            }

            return SUCCESS;
        }
    }
}
