/**
 * $Revision$
 * $Date$
 *
 * Copyright (C) 1999-2005 Jive Software. All rights reserved.
 * This software is the proprietary information of Jive Software. Use is subject to license terms.
 */

package com.jivesoftware.clearspace.plugin.clearfoxplugin;

import com.jivesoftware.community.action.util.AlwaysAllowAnonymous;
import com.jivesoftware.community.action.MainAction;
import com.jivesoftware.community.action.JiveActionSupport;
import com.jivesoftware.base.User;

/**
 * Action that gathers page refresh interval.
 */
public class SettingsAction extends JiveActionSupport {

    private int pollInterval = ClearFoxPlugin.REFRESH_DEFAULT;

    public void setPollInterval(int pollInterval) {
        this.pollInterval = pollInterval;
    }

    public String execute() {

        User user = getUser();
        if (user != null) {
            user.getProperties().put(ClearFoxPlugin.REFRESH_RATE, Integer.toString(pollInterval));
        }

        return SUCCESS;
    }
}
