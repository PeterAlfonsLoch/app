/**
 * $Revision$
 * $Date$
 *
 * Copyright (C) 1999-2005 Jive Software. All rights reserved.
 * This software is the proprietary information of Jive Software. Use is subject to license terms.
 */

package com.jivesoftware.clearspace.plugin.clearfoxplugin;

import com.jivesoftware.community.action.JiveActionSupport;
import com.jivesoftware.community.JiveGlobals;

/**
 * Simple action that populates values for the updater page (which is the page
 * that controls when Firefox notifies the user that a new version of Clearfox
 * is available).
 */
public class UpdaterAction extends JiveActionSupport {

    private String updateLink;
    private String version;

    public String getUpdateLink() {
        return updateLink;
    }

    public void setUpdateLink(String updateLink) {
        this.updateLink = updateLink;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String execute() {


        updateLink = JiveGlobals.getDefaultBaseURL() + "/plugins/clearfox/clearfox.xpi";
        version = ClearFoxPlugin.VERSION;

        return SUCCESS;
    }
}
