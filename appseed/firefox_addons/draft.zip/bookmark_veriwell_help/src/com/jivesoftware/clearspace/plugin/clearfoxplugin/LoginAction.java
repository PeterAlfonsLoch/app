/*
 * $Revision: 46151 $
 * $Date: 2007-06-11 19:33:34 -0700 (Mon, 11 Jun 2007) $
 *
 * Copyright (C) 1999-2006 Jive Software. All rights reserved.
 *
 * This software is the proprietary information of Jive Software.
 * Use is subject to license terms.
 */
package com.jivesoftware.clearspace.plugin.clearfoxplugin;


import com.jivesoftware.base.*;
import com.jivesoftware.community.action.util.AlwaysAllowAnonymous;
import com.jivesoftware.community.action.JiveActionSupport;

@AlwaysAllowAnonymous
public class LoginAction extends JiveActionSupport {

    /* show the unauth result if the user hit an unauthorized error */
    private static String UNAUTH = "unauth";


    // Parameters //
    protected String username;
    protected String password;
    protected boolean autoLogin = false;
    protected String successURL;
    protected String cancelURL;

    protected boolean unauth = false;

    public String execute() {
        if (username == null || username.length() == 0) {
            return UNAUTH;
        }

        if (password == null || password.length() == 0) {
            return UNAUTH;
        }

        try {
            AuthFactory.loginUser(username, password, autoLogin, request, response);
        }
        catch (Exception ue) {
            Log.error("error attemtping to authorize user", ue);
            return UNAUTH;
        }

        return SUCCESS;
    }



    /**
     * Returns the username used to do a login.
     *
     * @return the username used to do a login.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username used to do a login if the username is not null and not a zero-length String.
     *
     * @param username the username used to do a login.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Returns the password used to do a login.
     *
     * @return the password used to do a login.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password used to do a login if the password is not null and not a zero-length String.
     *
     * @param password the password used to do a login.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Returns true if the user wants to enable auto-login, false otherwise.
     *
     * @return true if the user wants to enable auto-login, false otherwise.
     */
    public boolean isAutoLogin() {
        return autoLogin;
    }

    /**
     * Sets whether or not the user wants to automatically login.
     *
     * @param autoLogin whether or not the user wants to automatically login.
     */
    public void setAutoLogin(boolean autoLogin) {
        this.autoLogin = autoLogin;
    }

}
