package com.jivesoftware.clearspace.plugin.clearfoxplugin;

/**
 *
 */
public class LogoutAction extends com.jivesoftware.community.action.LogoutAction {

    public String execute() {
        return super.execute();
    }
}
