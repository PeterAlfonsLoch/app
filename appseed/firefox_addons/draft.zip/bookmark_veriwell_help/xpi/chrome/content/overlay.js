var Clearfox = {

	startup: function()  {
		this.clearfoxLoadUrlInSidebar();
	},
	
	shutdown: function() {
		// empty
	},
	
	clearfoxLoadUrlInSidebar: function()  {
    	var sidebar = top.document.getElementById("sidebar");
    	var broadcaster = top.document.getElementById('viewSidebar');
		if (broadcaster.hasAttribute('checked')) {
        	sidebar.style.minWidth = '200px';
        	sidebar.style.width = '200px';

        	sidebar.contentWindow.addEventListener("DOMContentLoaded",
                    Clearfox.clearfoxContentLoaded, false);
            
            sidebar.loadURI("CLEARFOXURL");
    	}
	},
	
	clearfoxContentLoaded: function() {
    	Clearfox.clearfoxConvertLinks();

		// listen for new additions
    	var sidebar = top.document.getElementById("sidebar");
        var table = sidebar.contentDocument.getElementById("clearfox-hidden-content");
        table.addEventListener("DOMNodeRemoved", Clearfox.clearfoxConvertLinks, false);

        // listen for search button clicks
        var searchButton = sidebar.contentDocument.getElementById("jive-clearfox-qbutton");
        searchButton.addEventListener("click", Clearfox.clearfoxSubmitSearchForm, false);

        // listen for search input form submissions
        var searchInput = sidebar.contentDocument.getElementById("jive-clearfox-q");
        searchInput.addEventListener("keypress", Clearfox.clearfoxHandleKeyPress, false);

    },

    clearfoxHandleKeyPress: function(e) {
        if (e.which == 13) {
            Clearfox.clearfoxSubmitSearchForm();
        }
    },

    clearfoxSubmitSearchForm: function() {
        var sidebar = top.document.getElementById("sidebar");
        var searchValue = sidebar.contentDocument.getElementById("jive-clearfox-q").value;
        var searchURL = 'CLEARFOXURL'.replace('/cf-view.jspa', '/search/' + searchValue);
        if (searchValue != '') {
            gBrowser.selectedTab = gBrowser.addTab(searchURL);
        }
    },

    clearfoxCreateOpenFunction: function(url) {
        return function() {
            gBrowser.selectedTab = gBrowser.addTab(url);
    	};
	},

	clearfoxConvertLinks: function() {
        var sidebar = top.document.getElementById("sidebar");
    	var doc = sidebar.contentDocument;

    	var all_links = new Array();

	    var links = doc.evaluate("//a", doc, null, XPathResult.ANY_TYPE, null);
	    var link = links.iterateNext();
	    while (link) {
	        all_links.push(link);
	        link = links.iterateNext();
	    }

	    for (var i = 0; i < all_links.length; i++) {
	        link = all_links[i];
	        if (!link.hasAttribute('onclick') &&
	            link.hasAttribute('href') && link.getAttribute('class').indexOf('tabbable') > -1) {
	            var target = link.getAttribute('href');
	            link.setAttribute('onclick', 'return false;');
	            link.removeAttribute('target');
	            link.addEventListener('click', Clearfox.clearfoxCreateOpenFunction(target), true);
            }
	    }
	},
		
	clearfoxAddIconToNavbar: function() {
    	var toolbox = document.getElementById("navigator-toolbox");
    	var toolboxDocument = toolbox.ownerDocument;

    	var hasClearfoxButton = false;
	    for (var i = 0; i < toolbox.childNodes.length; ++i) {
	    	var toolbar = toolbox.childNodes[i];
	    	if (toolbar.localName == "toolbar" && toolbar.getAttribute("customizable") == "true" ) {
	    	    if (toolbar.currentSet.indexOf("clearfox-button") > -1)
	    		hasClearfoxButton = true;
	    	}
	    }

	    if (!hasClearfoxButton) {
	    	for (var i = 0; i < toolbox.childNodes.length; ++i) {
	    	    toolbar = toolbox.childNodes[i];
	    	    if (toolbar.localName == "toolbar" &&  toolbar.getAttribute("customizable") == "true"
	                && toolbar.id == "nav-bar") {
	    	   	var newSet = "";
	    	   	var child = toolbar.firstChild;
	    	   	while (child) {
	    	   	   if (!hasClearfoxButton && (child.id=="clearfox-button" || child.id=="urlbar-container")) {
	    		      newSet += "clearfox-button,";
	    		      hasClearfoxButton = true;
	    	   	   }

	    		    newSet += child.id + ",";
	    		    child = child.nextSibling;
	    		}

	    		newSet = newSet.substring(0, newSet.length-1);
	    		toolbar.currentSet = newSet;

	    		toolbar.setAttribute("currentset", newSet);
	    		toolboxDocument.persist(toolbar.id, "currentset");
	    		BrowserToolboxCustomizeDone(true)
	    		break;
	    	    }
	    	}
	    }
	}
}

window.addEventListener("load", function(e) { Clearfox.clearfoxAddIconToNavbar(); }, false);
window.addEventListener("load", function(e) { Clearfox.startup(); }, false);
window.addEventListener("unload", function(e) { Clearfox.shutdown(); }, false);

