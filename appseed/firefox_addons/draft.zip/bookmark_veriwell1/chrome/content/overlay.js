var BookmarkVeriwell = {

	startup: function()  {
		this.bookmarkveriwellLoadUrlInSidebar();
	},
	
	shutdown: function() {
		// empty
	},
	
		
	bookmarkveriwellAddIconToNavbar: function() {
    	var toolbox = document.getElementById("navigator-toolbox");
    	var toolboxDocument = toolbox.ownerDocument;

    	var hasBookmarkVeriwellButton = false;
	    for (var i = 0; i < toolbox.childNodes.length; ++i) {
	    	var toolbar = toolbox.childNodes[i];
	    	if (toolbar.localName == "toolbar" && toolbar.getAttribute("customizable") == "true" ) {
	    	    if (toolbar.currentSet.indexOf("bookmarkveriwellbutton") > -1)
	    		hasBookmarkVeriwellButton = true;
	    	}
	    }

	    if (!hasBookmarkVeriwellButton) {
	    	for (var i = 0; i < toolbox.childNodes.length; ++i) {
	    	    toolbar = toolbox.childNodes[i];
	    	    if (toolbar.localName == "toolbar" &&  toolbar.getAttribute("customizable") == "true"
	                && toolbar.id == "nav-bar") {
	    	   	var newSet = "";
	    	   	var child = toolbar.firstChild;
	    	   	while (child) {
	    	   	   if (!hasBookmarkVeriwellButton && (child.id=="bookmarkveriwellbutton" || child.id=="urlbar-container")) {
	    		      newSet += "bookmarkveriwellbutton,";
	    		      hasBookmarkVeriwellButton = true;
	    	   	   }

	    		    newSet += child.id + ",";
	    		    child = child.nextSibling;
	    		}

	    		newSet = newSet.substring(0, newSet.length-1);
	    		toolbar.currentSet = newSet;

	    		toolbar.setAttribute("currentset", newSet);
	    		toolboxDocument.persist(toolbar.id, "currentset");
	    		BrowserToolboxCustomizeDone(true)
	    		break;
	    	    }
	    	}
	    }
	}
}

window.addEventListener("load", function(e) { BookmarkVeriwell.bookmarkveriwellAddIconToNavbar(); }, false);
window.addEventListener("load", function(e) { BookmarkVeriwell.startup(); }, false);
window.addEventListener("unload", function(e) { BookmarkVeriwell.shutdown(); }, false);

